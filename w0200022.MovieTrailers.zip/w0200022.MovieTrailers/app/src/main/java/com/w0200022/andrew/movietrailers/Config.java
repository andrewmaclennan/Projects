package com.w0200022.andrew.movietrailers;


public class Config {
    public static final String YOUTUBE_API_KEY = "AIzaSyCgvQkiR8RH5rJjnOIJgKWUiBGRt8mSBFI";
    public static final String VIDEO_ID_KEY = "VIDEO_ID_KEY";
    public static final String MOVIE_TITLE_KEY = "MOVIE_TITLE_KEY";
    public static final String MOVIE_DESCRIPTION_KEY = "MOVIE_DESCRIPTION_KEY";
    public static final String TRAILER_RATING_KEY = "TRAILER_RATING_KEY";
}
